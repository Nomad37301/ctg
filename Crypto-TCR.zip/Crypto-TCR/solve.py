#!/usr/bin/env python3
# ROT13 Decoder Tool - Caesar's Cousin Challenge

import codecs

print("=" * 45)
print("   ROT13 DECODER - Caesar's Cousin")
print("=" * 45)
print()

# Ciphertext dari challenge.txt
ciphertext = "grpneg{e0g_guvegrra_vf_rnfl_crnfna}"

print(f"[*] Ciphertext  : {ciphertext}")

# Decode ROT13
plaintext = codecs.decode(ciphertext, 'rot_13')

print(f"[+] Hasil Decode: {plaintext}")
print()
print("=" * 45)
print("Flag ditemukan! Submit ke platform CTF :)")
print("=" * 45)
